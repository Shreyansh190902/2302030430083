# How to edit these greetings

Each folder (for example `diwali-post`) has:
- **`wudly-<festival>-<size>.psd`**: a layered Photoshop file with 3 layers. It opens in Photoshop or in the free https://www.photopea.com.
  1. Background (no text): the AI artwork
  2. Gold mandala + sparkles: decoration
  3. Text + logo: the greeting, wish line and Wudly logo
- The same 3 layers as separate PNG files, which you can use in Canva or any editor.

## To change the text
1. Hide or delete the **Text + logo** layer.
2. Type new text with the fonts in `fonts/`. Install them first.

| Text | Font | Size | Colour |
|---|---|---|---|
| Hindi greeting | Amita Bold, white | about 150px (post) | #FFFFFF |
| Small top word (शुभ / नूतन) | Amita Bold | about 64px | #F9A825 |
| Wish line | Montserrat Regular | 27px | #FFFFFF |

3. Add the logo from `brand-logos/wudly-logo-cream-badge-for-red-backgrounds.png`.

## In Canva
1. Upload `1-background-no-text.png` as the background.
2. Optionally add `2-gold-decoration.png` on top.
3. Add your own text boxes.

Note: the text in the PSD is a picture layer. For live, editable text, retype it with the included fonts.
